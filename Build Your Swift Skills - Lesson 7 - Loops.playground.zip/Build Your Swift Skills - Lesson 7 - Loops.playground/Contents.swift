import UIKit

var str = "Hello, playground"


var array = [Int]()


for _ in 0...10 {
    let randomNumber = Int(arc4random_uniform(11))
    array.append(randomNumber)
    //
    //array += [randomNumber]
  // print(randomNumber)
}

array.removeAll()

repeat{
     let randomNumber = Int(arc4random_uniform(10) + 1)
    //ganerate a random number
    if array.contains(randomNumber) == false {
        array.append(randomNumber)
    }
    
} while array.count < 10

for number in array {
    print(number)
}


